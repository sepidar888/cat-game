
from kivy.app import App
from kivy.uix.widget import Widget
from kivy.properties import NumericProperty, ObjectProperty
from kivy.clock import Clock
from kivy.uix.image import Image
from kivy.animation import Animation
import random

class Cat(Image):
    jump_count = NumericProperty(0)
    is_jumping = False

class GameScreen(Widget):
    cat = ObjectProperty(None)
    score = NumericProperty(0)
    game_started = False
    
    def __init__(self, **kwargs):
        super(GameScreen, self).__init__(**kwargs)
        self.fishes = []
    
    def on_touch_down(self, touch):
        if not self.cat.is_jumping and self.cat.jump_count < 2:
            self.cat_jump()
    
    def cat_jump(self):
        self.cat.is_jumping = True
        self.cat.jump_count += 1
        anim = Animation(y=self.cat.y + 150, duration=0.3)
        anim.bind(on_complete=self._fall_down)
        anim.start(self.cat)
    
    def _fall_down(self, *args):
        anim = Animation(y=100, duration=0.4)
        anim.bind(on_complete=self._jump_complete)
        anim.start(self.cat)
    
    def _jump_complete(self, *args):
        self.cat.is_jumping = False

class CatGameApp(App):
    def build(self):
        return GameScreen()

if __name__ == '__main__':
    CatGameApp().run()
